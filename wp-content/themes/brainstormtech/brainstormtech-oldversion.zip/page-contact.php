<?php
/**
 * The template for displaying all pages
 * Template Name: Contact page
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package brainstormtech
 */

get_header();
?>

    <main id="primary" class="page-content">
        <div class="contact-page">

            <div class="anim-circles rel">

                <div class="yellow"></div>
                <div class="blue"></div>
                <div class="purple"></div>

                <div class="elips-line"></div>

                <div class="container-fluid">
                    <div class="contact-container flex fjb">
                        <div class="contact-form">
                            <div class="form-section">
                                <div class="text-section">
                                    <h1 class="h3">Say Hi </h1>
                                    <p>Have an idea for a project? Leave your contact info below and we’ll get back to you in 24 hours. </p>
                                </div>
                                <form action="">
                                    <div class="form-content flex fwrap fjb">

                                        <div class="form-row radius-top">
                                            <label for="name">Your Name</label>
                                            <input id="name" type="text" name="name" >
                                        </div>

                                        <div class="form-row">
                                            <label for="phone">Your Phone</label>
                                            <input id="phone" type="text" name="phone" >
                                        </div>

                                        <div class="form-row radius-bottom">
                                            <label for="email">Your E-mail</label>
                                            <input id="email" type="text" name="email" >
                                        </div>

                                        <div class="submit-btn flex">
                                            <button class="btn big flex fac rel">
                                                <div class="flex fac fjc">
                                                        <span class="rel flex fac fjc">Send
                                                            <span class="btn-arrow"></span>
                                                        </span>
                                                </div>
                                                <span class="yellow"></span>
                                            </button>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <div class="success">
                                <h1 class="h3">Thanks!</h1>
                                <h4>Your submission has been accepted.</br>
                                    We will get back to you in 24 hours.</h4>
                            </div>

                        </div>

                        <div class="contact-info">
                            <div class="soc-info">
                                <a href="mailto:hello@brainstormtech.io" class="h4">hello@brainstormtech.io</a>
                                <a href="https://www.instagram.com/" target="_blank" class="h4">instagram</a>
                                <a href="https://www.behance.net/" target="_blank" class="h4">behance</a>
                                <a href="https://www.facebook.com/" target="_blank" class="h4">facebook</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>

<?php
get_footer();
